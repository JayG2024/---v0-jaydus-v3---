import { createClient } from "@supabase/supabase-js"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import type { Database } from "@/types/database.types"

// Client-side Supabase client (for components)
export const supabase = createClientComponentClient<Database>()

// Server-side Supabase client with service role for admin operations
export const createServerSupabaseClient = () => {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error("Missing Supabase environment variables")
    throw new Error("Missing required Supabase environment variables")
  }

  return createClient<Database>(supabaseUrl, supabaseServiceKey)
}

// Create database tables
export async function createDatabaseTables() {
  try {
    // Create conversations table
    const { error: conversationsError } = await supabase.rpc("exec_sql", {
      sql_query: `
        CREATE TABLE IF NOT EXISTS conversations (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          user_id UUID NOT NULL,
          title TEXT,
          model TEXT NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          is_pinned BOOLEAN DEFAULT FALSE,
          is_archived BOOLEAN DEFAULT FALSE,
          metadata JSONB
        );
      `,
    })

    if (conversationsError) {
      throw new Error(`Failed to create conversations table: ${conversationsError.message}`)
    }

    // Create messages table
    const { error: messagesError } = await supabase.rpc("exec_sql", {
      sql_query: `
        CREATE TABLE IF NOT EXISTS messages (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          conversation_id UUID NOT NULL,
          role TEXT NOT NULL,
          content TEXT NOT NULL,
          status TEXT DEFAULT 'completed',
          tokens_used INTEGER,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          metadata JSONB,
          FOREIGN KEY (conversation_id) REFERENCES conversations(id)
        );
      `,
    })

    if (messagesError) {
      throw new Error(`Failed to create messages table: ${messagesError.message}`)
    }

    return { success: true }
  } catch (error) {
    console.error("Error creating database tables:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : String(error),
    }
  }
}
