import { supabase } from "@/lib/supabase"
import type { Database } from "@/types/database.types"
import type { Message } from "ai"

type Tables = Database["public"]["Tables"]

// Check if conversations table exists
export async function checkConversationsTable() {
  const { count, error } = await supabase.from("conversations").select("*", { count: "exact", head: true })

  if (error) {
    console.error("Error checking conversations table:", error)
    throw error
  }

  return { count }
}

// Chat history functions
export async function createConversation(userId: string, model: string, title?: string) {
  console.log("Creating conversation in database for user:", userId, "with model:", model)

  try {
    const { data, error } = await supabase
      .from("conversations")
      .insert({
        user_id: userId,
        model,
        title: title || "New Conversation",
        is_pinned: false,
        is_archived: false,
        updated_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) {
      console.error("Supabase error creating conversation:", error)
      throw error
    }

    if (!data) {
      throw new Error("No data returned from conversation creation")
    }

    return data
  } catch (error) {
    console.error("Error in createConversation:", error)
    throw error
  }
}

export async function updateConversationTitle(conversationId: string, title: string) {
  const { data, error } = await supabase
    .from("conversations")
    .update({ title, updated_at: new Date().toISOString() })
    .eq("id", conversationId)
    .select()
    .single()

  if (error) throw error
  return data
}

export async function getUserConversations(userId: string) {
  const { data, error } = await supabase
    .from("conversations")
    .select("*")
    .eq("user_id", userId)
    .eq("is_archived", false)
    .order("updated_at", { ascending: false })

  if (error) throw error
  return data
}

export async function getConversation(conversationId: string) {
  const { data, error } = await supabase.from("conversations").select("*").eq("id", conversationId).single()

  if (error) throw error
  return data
}

export async function addMessage(
  conversationId: string,
  role: Tables["messages"]["Row"]["role"],
  content: string,
  tokensUsed?: number,
) {
  const { data, error } = await supabase
    .from("messages")
    .insert({
      conversation_id: conversationId,
      role,
      content,
      tokens_used: tokensUsed,
    })
    .select()
    .single()

  if (error) throw error
  return data
}

export async function getConversationMessages(conversationId: string) {
  const { data, error } = await supabase
    .from("messages")
    .select("*")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true })

  if (error) throw error
  return data
}

export async function deleteConversation(conversationId: string) {
  const { error } = await supabase.from("conversations").update({ is_archived: true }).eq("id", conversationId)

  if (error) throw error
  return true
}

export async function pinConversation(conversationId: string, isPinned: boolean) {
  const { data, error } = await supabase
    .from("conversations")
    .update({ is_pinned: isPinned })
    .eq("id", conversationId)
    .select()
    .single()

  if (error) throw error
  return data
}

// Convert database messages to AI SDK message format
export function convertDbMessagesToAiMessages(dbMessages: Tables["messages"]["Row"][]): Message[] {
  return dbMessages.map((msg) => ({
    id: msg.id,
    role: msg.role,
    content: msg.content,
  }))
}

// Convert AI SDK messages to database format
export function convertAiMessagesToDbFormat(
  aiMessages: Message[],
  conversationId: string,
): Omit<Tables["messages"]["Insert"], "id" | "created_at">[] {
  return aiMessages.map((msg) => ({
    conversation_id: conversationId,
    role: msg.role as Tables["messages"]["Row"]["role"],
    content: msg.content,
    status: "completed",
  }))
}
