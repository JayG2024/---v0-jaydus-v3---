import { openai } from "@ai-sdk/openai"

// Validate OpenAI configuration
export function validateOpenAIConfig() {
  const apiKey = process.env.OPENAI_API_KEY

  if (!apiKey) {
    throw new Error("OPENAI_API_KEY is not configured")
  }

  if (apiKey.startsWith("sk-") === false) {
    throw new Error("OPENAI_API_KEY appears to be invalid (should start with 'sk-')")
  }

  return true
}

// Get configured OpenAI model
export function getOpenAIModel(modelName = "gpt-4o") {
  validateOpenAIConfig()

  // Map frontend model names to actual OpenAI model identifiers
  const modelMap: Record<string, string> = {
    "gpt-4o": "gpt-4o",
    "gpt-4.1": "gpt-4-turbo-preview", // Adjust based on actual model names
    "gpt-3.5": "gpt-3.5-turbo",
    "o3-mini": "gpt-3.5-turbo", // Placeholder - replace with actual model when available
    "o4-mini": "gpt-4o-mini", // Placeholder - replace with actual model when available
  }

  const actualModel = modelMap[modelName] || "gpt-4o"
  return openai(actualModel)
}
