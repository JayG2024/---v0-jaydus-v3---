"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Copy, Download, Play } from "lucide-react"
import { CodeEditor } from "@/components/code-canvas/code-editor"
import { CodeOutput } from "@/components/code-canvas/code-output"

export function CodeCanvas() {
  const [prompt, setPrompt] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [language, setLanguage] = useState("javascript")
  const [code, setCode] = useState("")
  const [output, setOutput] = useState("")
  const [activeTab, setActiveTab] = useState("editor")

  const handleGenerateCode = async () => {
    if (!prompt.trim()) return

    setIsProcessing(true)

    // Simulate code generation
    setTimeout(() => {
      // Example generated code based on language
      let generatedCode = ""

      if (language === "javascript") {
        generatedCode = `// Generated JavaScript code
function calculateSum(numbers) {
  return numbers.reduce((sum, num) => sum + num, 0);
}

const numbers = [1, 2, 3, 4, 5];
console.log(\`Sum: \${calculateSum(numbers)}\`);`
      } else if (language === "python") {
        generatedCode = `# Generated Python code
def calculate_sum(numbers):
    return sum(numbers)

numbers = [1, 2, 3, 4, 5]
print(f"Sum: {calculate_sum(numbers)}")`
      } else if (language === "typescript") {
        generatedCode = `// Generated TypeScript code
function calculateSum(numbers: number[]): number {
  return numbers.reduce((sum, num) => sum + num, 0);
}

const numbers: number[] = [1, 2, 3, 4, 5];
console.log(\`Sum: \${calculateSum(numbers)}\`);`
      }

      setCode(generatedCode)
      setIsProcessing(false)
      setActiveTab("editor")
    }, 1500)
  }

  const handleRunCode = () => {
    setIsProcessing(true)

    // Simulate code execution
    setTimeout(() => {
      setOutput("Sum: 15")
      setIsProcessing(false)
      setActiveTab("output")
    }, 1000)
  }

  const handleCopyCode = () => {
    navigator.clipboard.writeText(code)
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-[calc(100vh-180px)]">
      <div className="flex flex-col space-y-4">
        <Card className="flex-1">
          <CardContent className="p-4 h-full flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Prompt</h2>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select Language" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="javascript">JavaScript</SelectItem>
                  <SelectItem value="typescript">TypeScript</SelectItem>
                  <SelectItem value="python">Python</SelectItem>
                  <SelectItem value="java">Java</SelectItem>
                  <SelectItem value="csharp">C#</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the code you want to generate..."
              className="flex-1 resize-none mb-4"
            />

            <Button onClick={handleGenerateCode} disabled={!prompt.trim() || isProcessing} className="w-full">
              {isProcessing ? "Generating..." : "Generate Code"}
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col space-y-4">
        <div className="flex justify-between items-center">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="editor">Editor</TabsTrigger>
              <TabsTrigger value="output">Output</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <Card className="flex-1">
          <CardContent className="p-4 h-full">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsContent value="editor" className="h-full mt-0">
                <div className="flex flex-col h-full">
                  <div className="flex justify-end space-x-2 mb-2">
                    <Button variant="outline" size="sm" onClick={handleCopyCode}>
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                    <Button size="sm" onClick={handleRunCode} disabled={!code.trim() || isProcessing}>
                      <Play className="h-4 w-4 mr-2" />
                      Run
                    </Button>
                  </div>
                  <CodeEditor code={code} language={language} onChange={setCode} />
                </div>
              </TabsContent>

              <TabsContent value="output" className="h-full mt-0">
                <CodeOutput output={output} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
