interface CodeOutputProps {
  output: string
}

export function CodeOutput({ output }: CodeOutputProps) {
  return (
    <div className="h-full w-full overflow-auto rounded-md border bg-black text-white">
      <pre className="p-4 text-sm font-mono">{output || "No output yet. Run your code to see results."}</pre>
    </div>
  )
}
