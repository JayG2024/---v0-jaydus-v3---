"use client"

interface CodeEditorProps {
  code: string
  language: string
  onChange: (code: string) => void
}

export function CodeEditor({ code, language, onChange }: CodeEditorProps) {
  return (
    <div className="relative h-full w-full overflow-auto rounded-md border bg-muted">
      <pre className="p-4 text-sm font-mono">
        <code>{code}</code>
      </pre>
      <textarea
        value={code}
        onChange={(e) => onChange(e.target.value)}
        className="absolute inset-0 w-full h-full p-4 font-mono text-sm bg-transparent resize-none outline-none"
      />
    </div>
  )
}
