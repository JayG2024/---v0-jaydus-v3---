"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ImageModelSelectorProps {
  selectedModel: string
  onSelectModel: (model: string) => void
}

export function ImageModelSelector({ selectedModel, onSelectModel }: ImageModelSelectorProps) {
  return (
    <Select value={selectedModel} onValueChange={onSelectModel}>
      <SelectTrigger className="w-[250px]">
        <SelectValue placeholder="Select Model" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="gemini-2.0-flash">Google Gemini 2.0 Flash</SelectItem>
        <SelectItem value="gemini-2.5-experimental">Google Gemini 2.5 Experimental</SelectItem>
        <SelectItem value="dall-e-3">DALL·E 3</SelectItem>
        <SelectItem value="dall-e-2">DALL·E 2</SelectItem>
      </SelectContent>
    </Select>
  )
}
