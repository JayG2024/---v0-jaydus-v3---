"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Download, Trash } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

type GeneratedImage = {
  id: string
  url: string
  prompt: string
  model: string
  timestamp: Date
}

interface ImageGalleryProps {
  images: GeneratedImage[]
}

export function ImageGallery({ images }: ImageGalleryProps) {
  const [selectedImage, setSelectedImage] = useState<GeneratedImage | null>(null)

  if (images.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center">
        <div className="rounded-full bg-muted p-6 mb-4">
          <img src="/placeholder.svg?height=64&width=64" alt="Empty gallery" className="h-16 w-16 opacity-50" />
        </div>
        <h3 className="text-lg font-medium mb-2">No images generated yet</h3>
        <p className="text-muted-foreground">Use the prompt tab to generate your first image</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {images.map((image) => (
        <Card key={image.id} className="overflow-hidden">
          <CardContent className="p-0">
            <Dialog>
              <DialogTrigger asChild>
                <button className="w-full h-48 overflow-hidden" onClick={() => setSelectedImage(image)}>
                  <img
                    src={image.url || "/placeholder.svg"}
                    alt={image.prompt}
                    className="w-full h-full object-cover transition-transform hover:scale-105"
                  />
                </button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Image Details</DialogTitle>
                  <DialogDescription>
                    Generated with {image.model} on {image.timestamp.toLocaleString()}
                  </DialogDescription>
                </DialogHeader>
                <div className="flex flex-col space-y-4">
                  <img src={image.url || "/placeholder.svg"} alt={image.prompt} className="w-full rounded-lg" />
                  <div className="text-sm">
                    <strong>Prompt:</strong> {image.prompt}
                  </div>
                  <div className="flex justify-end">
                    <Button variant="outline" className="mr-2">
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
          <CardFooter className="p-2 flex justify-between">
            <Button variant="ghost" size="sm">
              <Download className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Trash className="h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
