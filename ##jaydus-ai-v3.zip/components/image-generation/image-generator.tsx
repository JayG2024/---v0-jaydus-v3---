"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ImageIcon, Loader2 } from "lucide-react"
import { ImageGallery } from "@/components/image-generation/image-gallery"
import { ImageModelSelector } from "@/components/image-generation/image-model-selector"

type GeneratedImage = {
  id: string
  url: string
  prompt: string
  model: string
  timestamp: Date
}

export function ImageGenerator() {
  const [prompt, setPrompt] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [selectedModel, setSelectedModel] = useState("gemini-2.0-flash")
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([])
  const [activeTab, setActiveTab] = useState("prompt")

  const handleGenerateImage = async () => {
    if (!prompt.trim()) return

    setIsGenerating(true)

    // Simulate image generation
    setTimeout(() => {
      const newImage: GeneratedImage = {
        id: Date.now().toString(),
        url: `/placeholder.svg?height=512&width=512`,
        prompt,
        model: selectedModel,
        timestamp: new Date(),
      }

      setGeneratedImages((prev) => [newImage, ...prev])
      setIsGenerating(false)
      setActiveTab("gallery")
    }, 2000)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <ImageModelSelector selectedModel={selectedModel} onSelectModel={setSelectedModel} />
        <Button variant="outline" onClick={() => setGeneratedImages([])}>
          Clear Gallery
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="prompt">Prompt</TabsTrigger>
          <TabsTrigger value="gallery">Gallery ({generatedImages.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="prompt">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <label htmlFor="prompt" className="text-sm font-medium">
                  Image Prompt
                </label>
                <Textarea
                  id="prompt"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe the image you want to generate..."
                  className="min-h-[120px] resize-none"
                />
              </div>

              <div className="flex justify-end">
                <Button
                  onClick={handleGenerateImage}
                  disabled={!prompt.trim() || isGenerating}
                  className="w-full sm:w-auto"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <ImageIcon className="mr-2 h-4 w-4" />
                      Generate Image
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gallery">
          <ImageGallery images={generatedImages} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
