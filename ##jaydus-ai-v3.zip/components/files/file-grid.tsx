"use client"

import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { File, FileText, FileImage, FileCode, MoreHorizontal, Download, Trash } from "lucide-react"

type FileItem = {
  id: string
  name: string
  type: "document" | "image" | "code" | "data"
  size: string
  lastModified: Date
}

interface FileGridProps {
  files: FileItem[]
  onDelete: (id: string) => void
}

export function FileGrid({ files, onDelete }: FileGridProps) {
  const getFileIcon = (type: string) => {
    switch (type) {
      case "document":
        return <FileText className="h-12 w-12" />
      case "image":
        return <FileImage className="h-12 w-12" />
      case "code":
        return <FileCode className="h-12 w-12" />
      default:
        return <File className="h-12 w-12" />
    }
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
      {files.map((file) => (
        <div
          key={file.id}
          className="flex flex-col items-center p-4 border rounded-lg hover:bg-accent transition-colors"
        >
          <div className="mb-2 text-muted-foreground">{getFileIcon(file.type)}</div>
          <div className="text-center">
            <p className="text-sm font-medium truncate w-full max-w-[120px]">{file.name}</p>
            <p className="text-xs text-muted-foreground">{file.size}</p>
          </div>
          <div className="mt-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onDelete(file.id)}>
                  <Trash className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      ))}
    </div>
  )
}
