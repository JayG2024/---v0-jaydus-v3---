"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"

type Message = {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  timestamp: Date
  model?: string
}

interface ChatMessageProps {
  message: Message
  onRegenerate?: (messageId: string) => void
}

export function ChatMessage({ message, onRegenerate }: ChatMessageProps) {
  const isUser = message.role === "user"
  const { toast } = useToast()
  const [isRegenerating, setIsRegenerating] = useState(false)

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content)
    toast({
      description: "Message copied to clipboard",
    })
  }

  const handleRegenerate = () => {
    if (onRegenerate) {
      setIsRegenerating(true)
      onRegenerate(message.id)
      // The parent component should handle the actual regeneration
      // This will be reset when the message is replaced
    } else {
      toast({
        description: "Regenerate functionality not implemented yet",
      })
      setIsRegenerating(false)
    }
  }

  return (
    <div className={cn("flex items-start gap-3 p-4", isUser ? "justify-end" : "justify-start")}>
      {!isUser && (
        <Avatar>
          <AvatarFallback>AI</AvatarFallback>
          <AvatarImage src="/placeholder.svg?height=40&width=40" />
        </Avatar>
      )}
      <div
        className={cn("rounded-lg px-4 py-2 max-w-[80%]", isUser ? "bg-primary text-primary-foreground" : "bg-muted")}
      >
        <div className="whitespace-pre-wrap">{message.content}</div>
        <div
          className={cn(
            "text-xs mt-1 flex items-center justify-between",
            isUser ? "text-primary-foreground/70" : "text-muted-foreground",
          )}
        >
          <div className="flex items-center gap-1">
            {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
            {!isUser && message.model && (
              <span className="ml-2 px-1.5 py-0.5 rounded bg-secondary text-secondary-foreground text-[10px]">
                {message.model}
              </span>
            )}
          </div>
          {!isUser && (
            <div className="flex items-center gap-1.5">
              <button
                onClick={handleCopy}
                className="opacity-70 hover:opacity-100 transition-opacity"
                title="Copy to clipboard"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-copy"
                >
                  <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
                  <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
                </svg>
              </button>
              <button
                onClick={handleRegenerate}
                className={`opacity-70 hover:opacity-100 transition-opacity ${isRegenerating ? "animate-spin" : ""}`}
                title="Regenerate response"
                disabled={isRegenerating}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-refresh-cw"
                >
                  <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
                  <path d="M21 3v5h-5" />
                  <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
                  <path d="M8 16H3v5" />
                </svg>
              </button>
            </div>
          )}
        </div>
      </div>
      {isUser && (
        <Avatar>
          <AvatarFallback>You</AvatarFallback>
          <AvatarImage src="/placeholder.svg?height=40&width=40" />
        </Avatar>
      )}
    </div>
  )
}
