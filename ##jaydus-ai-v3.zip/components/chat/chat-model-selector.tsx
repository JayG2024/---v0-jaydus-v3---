"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ChatModelSelectorProps {
  selectedModel: string
  onSelectModel: (model: string) => void
}

export function ChatModelSelector({ selectedModel, onSelectModel }: ChatModelSelectorProps) {
  return (
    <Select value={selectedModel} onValueChange={onSelectModel}>
      <SelectTrigger className="w-[200px]">
        <SelectValue placeholder="Select Model" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="gpt-4o">GPT-4o</SelectItem>
        <SelectItem value="gpt-4-turbo">GPT-4.1</SelectItem>
        <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
        <SelectItem value="gpt-4o-mini">O4 Mini</SelectItem>
      </SelectContent>
    </Select>
  )
}
