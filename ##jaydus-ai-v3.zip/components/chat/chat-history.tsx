"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageSquare, Plus, Trash, Pin, PinOff, Edit, Check, X, AlertCircle } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import type { Database } from "@/types/database.types"
import {
  getUserConversations,
  deleteConversation,
  togglePinConversation,
  updateConversationTitle,
} from "@/app/actions/chat-actions"

type Conversation = Database["public"]["Tables"]["conversations"]["Row"]

interface ChatHistoryProps {
  activeConversationId?: string
  onNewChat: () => void
  onSelectConversation: (id: string) => void
}

export function ChatHistory({ activeConversationId, onNewChat, onSelectConversation }: ChatHistoryProps) {
  const router = useRouter()
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [loading, setLoading] = useState(true)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editTitle, setEditTitle] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [setupRequired, setSetupRequired] = useState(false)

  // Fetch conversations
  const fetchConversations = async () => {
    setLoading(true)
    setError(null)
    try {
      const result = await getUserConversations()
      if (result.success && result.conversations) {
        setConversations(result.conversations)
      } else if (result.error) {
        console.error("Error fetching conversations:", result.error)

        // Check if the error is about missing tables
        if (result.error.includes("does not exist")) {
          setSetupRequired(true)
          setError("Database tables need to be set up")
        } else {
          setError(`Failed to load conversations: ${result.error}`)
        }
      }
    } catch (error) {
      console.error("Error fetching conversations:", error)
      setError("Failed to load conversations")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchConversations()
  }, [])

  // Handle database setup
  const handleSetupDatabase = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch("/api/setup-database")
      const data = await response.json()

      if (data.success) {
        setSetupRequired(false)
        fetchConversations()
      } else {
        setError(`Failed to set up database: ${data.error}`)
      }
    } catch (error) {
      console.error("Error setting up database:", error)
      setError("Failed to set up database")
    } finally {
      setLoading(false)
    }
  }

  // Handle conversation deletion
  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    try {
      await deleteConversation(id)
      setConversations(conversations.filter((conv) => conv.id !== id))

      // If the deleted conversation was active, redirect to new chat
      if (id === activeConversationId) {
        onNewChat()
      }
    } catch (error) {
      console.error("Error deleting conversation:", error)
    }
  }

  // Handle pin/unpin
  const handleTogglePin = async (id: string, isPinned: boolean, e: React.MouseEvent) => {
    e.stopPropagation()
    try {
      await togglePinConversation(id, !isPinned)
      setConversations(conversations.map((conv) => (conv.id === id ? { ...conv, is_pinned: !isPinned } : conv)))
    } catch (error) {
      console.error("Error toggling pin status:", error)
    }
  }

  // Start editing title
  const handleStartEdit = (id: string, currentTitle: string, e: React.MouseEvent) => {
    e.stopPropagation()
    setEditingId(id)
    setEditTitle(currentTitle)
  }

  // Save edited title
  const handleSaveTitle = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (editTitle.trim()) {
      try {
        await updateConversationTitle(id, editTitle)
        setConversations(conversations.map((conv) => (conv.id === id ? { ...conv, title: editTitle } : conv)))
      } catch (error) {
        console.error("Error updating title:", error)
      }
    }
    setEditingId(null)
  }

  // Cancel editing
  const handleCancelEdit = (e: React.MouseEvent) => {
    e.stopPropagation()
    setEditingId(null)
  }

  // Sort conversations: pinned first, then by updated_at
  const sortedConversations = [...conversations].sort((a, b) => {
    if (a.is_pinned && !b.is_pinned) return -1
    if (!a.is_pinned && b.is_pinned) return 1
    return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
  })

  return (
    <div className="flex flex-col h-full">
      <div className="p-4">
        <Button onClick={onNewChat} className="w-full justify-start">
          <Plus className="mr-2 h-4 w-4" />
          New Chat
        </Button>
      </div>

      <ScrollArea className="flex-1">
        <div className="px-4 py-2">
          <h2 className="text-sm font-semibold mb-2">Conversations</h2>

          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                {error}
                {setupRequired && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2 w-full"
                    onClick={handleSetupDatabase}
                    disabled={loading}
                  >
                    {loading ? "Setting up..." : "Set up database tables"}
                  </Button>
                )}
              </AlertDescription>
            </Alert>
          )}

          {loading ? (
            <div className="flex items-center justify-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
            </div>
          ) : sortedConversations.length === 0 && !error ? (
            <div className="text-sm text-muted-foreground py-4 text-center">No conversations yet</div>
          ) : (
            <div className="space-y-1">
              {sortedConversations.map((conversation) => (
                <div
                  key={conversation.id}
                  onClick={() => onSelectConversation(conversation.id)}
                  className={`flex items-center justify-between p-2 rounded-md cursor-pointer hover:bg-accent group ${
                    activeConversationId === conversation.id ? "bg-accent" : ""
                  }`}
                >
                  <div className="flex items-center overflow-hidden flex-1">
                    <MessageSquare className="h-4 w-4 mr-2 flex-shrink-0" />

                    {editingId === conversation.id ? (
                      <Input
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        onClick={(e) => e.stopPropagation()}
                        autoFocus
                        className="h-7 text-sm"
                      />
                    ) : (
                      <span className="text-sm truncate">{conversation.title || "New Conversation"}</span>
                    )}
                  </div>

                  <div
                    className={`flex space-x-1 ${editingId === conversation.id ? "visible" : "invisible group-hover:visible"}`}
                  >
                    {editingId === conversation.id ? (
                      <>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={(e) => handleSaveTitle(conversation.id, e)}
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleCancelEdit}>
                          <X className="h-4 w-4" />
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={(e) => handleStartEdit(conversation.id, conversation.title || "New Conversation", e)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={(e) => handleTogglePin(conversation.id, conversation.is_pinned, e)}
                        >
                          {conversation.is_pinned ? <PinOff className="h-4 w-4" /> : <Pin className="h-4 w-4" />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive"
                          onClick={(e) => handleDelete(conversation.id, e)}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  )
}
