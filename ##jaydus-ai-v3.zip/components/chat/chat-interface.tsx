"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { useChat } from "ai/react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Mic, Send, StopCircle, AlertCircle, Loader2 } from "lucide-react"
import { ChatMessage } from "@/components/chat/chat-message"
import { ChatModelSelector } from "@/components/chat/chat-model-selector"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import type { Message } from "ai"
import { saveMessagesToConversation } from "@/app/actions/chat-actions"
import { useToast } from "@/hooks/use-toast"
import type { SpeechRecognition } from "webkit-speech-api"

interface ChatInterfaceProps {
  initialMessages?: Message[]
  conversationId?: string
  onCreateNewConversation?: (model: string, firstMessage: string) => Promise<string | null>
  initialModel?: string
  onRegenerateMessage?: (messageId: string) => void
}

export function ChatInterface({
  initialMessages = [],
  conversationId,
  onCreateNewConversation,
  initialModel = "gpt-4o",
  onRegenerateMessage,
}: ChatInterfaceProps) {
  const [selectedModel, setSelectedModel] = useState(initialModel)
  const [isRecording, setIsRecording] = useState(false)
  const [recordingStream, setRecordingStream] = useState<MediaStream | null>(null)
  const [recordedAudio, setRecordedAudio] = useState<Blob | null>(null)
  const [isTranscribing, setIsTranscribing] = useState(false)
  const [useWebSpeechAPI, setUseWebSpeechAPI] = useState(false)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [isSaving, setIsSaving] = useState(false)
  const { toast } = useToast()
  const recognitionRef = useRef<SpeechRecognition | null>(null)

  const { messages, input, setInput, handleInputChange, handleSubmit, isLoading, stop, error, reload, setMessages } =
    useChat({
      api: "/api/chat",
      initialMessages,
      body: {
        model: selectedModel,
        conversationId,
      },
      onResponse: (response) => {
        // This is called when the API starts streaming a response
        setErrorMessage(null)
      },
      onFinish: async (message) => {
        // This is called when the API response is complete
        if (!conversationId && onCreateNewConversation) {
          // If this is a new conversation, create it in the database
          setIsSaving(true)
          try {
            const firstUserMessage = messages.find((m) => m.role === "user")
            const newConversationId = await onCreateNewConversation(
              selectedModel,
              firstUserMessage?.content || "New conversation",
            )

            if (newConversationId) {
              // Save all messages to the new conversation
              await saveMessagesToConversation(newConversationId, [...messages, message])
            } else {
              console.error("Failed to create conversation: No ID returned")
              setErrorMessage("Failed to save conversation. Please try again.")
            }
          } catch (error) {
            console.error("Error creating new conversation:", error)
            setErrorMessage(`Failed to save conversation: ${error instanceof Error ? error.message : "Unknown error"}`)
          } finally {
            setIsSaving(false)
          }
        }
      },
      onError: (error) => {
        console.error("Error in chat:", error)
        setErrorMessage("Failed to communicate with AI. Please try again.")
      },
    })

  // Check if Web Speech API is available
  useEffect(() => {
    const checkWebSpeechAPI = async () => {
      // First check if the browser supports Web Speech API
      if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
        console.log("Web Speech API is not supported in this browser")
        setUseWebSpeechAPI(false)
        return
      }

      // Then check if Whisper API is available
      try {
        const response = await fetch("/api/test-whisper-specific")
        if (response.ok) {
          const data = await response.json()
          if (!data.success) {
            console.log("Whisper API is not available, using Web Speech API fallback")
            setUseWebSpeechAPI(true)
          }
        } else {
          console.log("Error checking Whisper API, using Web Speech API fallback")
          setUseWebSpeechAPI(true)
        }
      } catch (error) {
        console.log("Error checking Whisper API, using Web Speech API fallback")
        setUseWebSpeechAPI(true)
      }
    }

    checkWebSpeechAPI()
  }, [])

  // Update messages when initialMessages change (e.g., when loading a conversation)
  useEffect(() => {
    if (initialMessages.length > 0) {
      setMessages(initialMessages)
    }
  }, [initialMessages, setMessages])

  // Clear error when input changes
  useEffect(() => {
    if (errorMessage && input) {
      setErrorMessage(null)
    }
  }, [input, errorMessage])

  // Scroll to bottom whenever messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e)
    }
  }

  const toggleRecording = async () => {
    if (isRecording) {
      // Stop recording
      if (useWebSpeechAPI) {
        if (recognitionRef.current) {
          recognitionRef.current.stop()
        }
      } else {
        if (mediaRecorderRef.current) {
          mediaRecorderRef.current.stop()
          if (recordingStream) {
            recordingStream.getTracks().forEach((track) => track.stop())
            setRecordingStream(null)
          }
        }
      }
      setIsRecording(false)
    } else {
      if (useWebSpeechAPI) {
        // Use Web Speech API
        startWebSpeechRecognition()
      } else {
        // Use MediaRecorder API for Whisper
        startMediaRecording()
      }
    }
  }

  const startWebSpeechRecognition = () => {
    try {
      // Initialize Web Speech API
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      const recognition = new SpeechRecognition()

      recognition.continuous = true
      recognition.interimResults = true
      recognition.lang = "en-US"

      let finalTranscript = ""

      recognition.onstart = () => {
        setIsRecording(true)
        setInput("Listening...")
        toast({
          title: "Listening",
          description: "Speak clearly into your microphone",
        })
      }

      recognition.onresult = (event) => {
        let interimTranscript = ""

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript
          if (event.results[i].isFinal) {
            finalTranscript += transcript + " "
          } else {
            interimTranscript += transcript
          }
        }

        setInput(finalTranscript + interimTranscript)
      }

      recognition.onerror = (event) => {
        console.error("Speech recognition error", event.error)
        setIsRecording(false)
        toast({
          variant: "destructive",
          title: "Recognition Error",
          description: `Error: ${event.error}`,
        })
      }

      recognition.onend = () => {
        setIsRecording(false)
        if (finalTranscript) {
          toast({
            title: "Recognition complete",
            description: "Your speech has been converted to text",
          })
        }
      }

      recognitionRef.current = recognition
      recognition.start()
    } catch (error) {
      console.error("Error starting Web Speech recognition:", error)
      toast({
        variant: "destructive",
        title: "Recognition Error",
        description: "Could not start speech recognition",
      })
    }
  }

  const startMediaRecording = async () => {
    try {
      // Start recording
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      setRecordingStream(stream)

      // Try to use webm format if supported
      let mimeType = "audio/webm"
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        // Fallback options
        if (MediaRecorder.isTypeSupported("audio/mp4")) {
          mimeType = "audio/mp4"
        } else if (MediaRecorder.isTypeSupported("audio/ogg")) {
          mimeType = "audio/ogg"
        }
      }

      console.log(`Using audio MIME type: ${mimeType}`)

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: mimeType,
      })

      mediaRecorderRef.current = mediaRecorder
      audioChunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data)
        }
      }

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: mimeType })
        console.log("Recording stopped, blob created:", {
          size: audioBlob.size,
          type: audioBlob.type,
        })
        setRecordedAudio(audioBlob)
        processAudioToText(audioBlob)
      }

      mediaRecorder.start()
      setIsRecording(true)
      toast({
        title: "Recording started",
        description: "Speak clearly into your microphone",
      })
    } catch (error) {
      console.error("Error accessing microphone:", error)
      toast({
        variant: "destructive",
        title: "Microphone access error",
        description: "Could not access your microphone. Please check your browser permissions.",
      })
    }
  }

  // Process recorded audio to text using Whisper
  const processAudioToText = async (audioBlob: Blob) => {
    setIsTranscribing(true)
    setInput("Transcribing your audio...")

    try {
      // Log audio details for debugging
      console.log("Audio blob details:", {
        size: audioBlob.size,
        type: audioBlob.type,
      })

      // Create form data to send the audio file
      const formData = new FormData()
      formData.append("audio", audioBlob, `recording.${audioBlob.type.split("/")[1] || "webm"}`)

      // Send to our API endpoint with better error logging
      console.log("Sending audio to transcription API...")
      const response = await fetch("/api/transcribe", {
        method: "POST",
        body: formData,
      })

      console.log("Transcription API response status:", response.status)

      // Check if response is ok before trying to parse JSON
      if (!response.ok) {
        // Try to get error details from response
        let errorDetails = ""
        try {
          const errorData = await response.json()
          console.log("Error response data:", errorData)
          errorDetails = errorData.error || errorData.message || errorData.details || ""
        } catch (jsonError) {
          // If we can't parse JSON, get text content
          try {
            const textContent = await response.text()
            console.log("Error response text:", textContent.substring(0, 200))
            errorDetails = textContent.substring(0, 100) + "..." // Limit length
          } catch (textError) {
            errorDetails = `HTTP error ${response.status}`
          }
        }

        throw new Error(`Server error: ${response.status} - ${errorDetails}`)
      }

      // Parse JSON response
      const result = await response.json()
      console.log("Transcription result:", result)

      if (result.success && result.text) {
        setInput(result.text)
        toast({
          title: "Transcription complete",
          description: "Your speech has been converted to text",
        })
      } else {
        throw new Error(result.error || "Failed to transcribe audio")
      }
    } catch (error) {
      console.error("Error transcribing audio:", error)
      toast({
        variant: "destructive",
        title: "Transcription failed",
        description: error instanceof Error ? error.message : "Could not transcribe your audio",
      })
      setInput("")
    } finally {
      setIsTranscribing(false)
    }
  }

  const handleClearChat = () => {
    window.location.reload()
  }

  const handleRetry = () => {
    setErrorMessage(null)
    reload()
  }

  const handleModelChange = (model: string) => {
    setSelectedModel(model)
  }

  const handleStop = () => {
    stop()
    console.log("Stopping AI response generation")
  }

  return (
    <div className="flex flex-col h-[calc(100vh-180px)]">
      <div className="flex justify-between items-center mb-4">
        <ChatModelSelector selectedModel={selectedModel} onSelectModel={handleModelChange} />
        <Button variant="outline" onClick={handleClearChat}>
          Clear Chat
        </Button>
      </div>

      {errorMessage && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription className="flex justify-between items-center">
            <span>{errorMessage}</span>
            <Button variant="outline" size="sm" onClick={handleRetry}>
              Retry
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <Card className="flex-1 overflow-hidden">
        <CardContent className="p-4 h-full flex flex-col">
          <div className="flex-1 overflow-y-auto mb-4">
            {messages.length === 0 ? (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                Start a conversation with the AI
              </div>
            ) : (
              messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  message={{
                    id: message.id,
                    role: message.role,
                    content: message.content,
                    timestamp: new Date(),
                    model: message.role === "assistant" ? selectedModel : undefined,
                  }}
                  onRegenerate={message.role === "assistant" ? onRegenerateMessage : undefined}
                />
              ))
            )}
            {(isLoading || isSaving) && (
              <div className="flex items-center space-x-2 p-4 bg-muted/50 rounded-lg">
                <div className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <div className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-2 h-2 bg-current rounded-full animate-bounce"></div>
                <span className="text-sm text-muted-foreground ml-2">
                  {isSaving ? "Saving conversation..." : "AI is thinking..."}
                </span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="flex items-end gap-2">
            <Textarea
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Type your message..."
              className="min-h-[60px] resize-none"
              disabled={isLoading || isSaving || isTranscribing}
            />
            <div className="flex flex-col gap-2">
              <Button
                size="icon"
                onClick={toggleRecording}
                variant={isRecording ? "destructive" : "secondary"}
                disabled={isLoading || isSaving || isTranscribing}
                title={useWebSpeechAPI ? "Using Web Speech API" : "Using Whisper API"}
              >
                {isRecording ? (
                  <StopCircle className="h-4 w-4" />
                ) : isTranscribing ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Mic className="h-4 w-4" />
                )}
              </Button>
              <Button
                size="icon"
                onClick={(e) => handleSubmit(e)}
                disabled={!input.trim() || isLoading || isSaving || isTranscribing}
              >
                <Send className="h-4 w-4" />
              </Button>
              {isLoading && (
                <Button size="icon" variant="outline" onClick={handleStop}>
                  <StopCircle className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
