"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Play, Upload, Pause } from "lucide-react"
import { VoiceSelector } from "@/components/voice/voice-selector"
import { TranscriptionPanel } from "@/components/voice/transcription-panel"

export function VoiceFeatures() {
  const [activeTab, setActiveTab] = useState("text-to-speech")
  const [text, setText] = useState("")
  const [selectedVoice, setSelectedVoice] = useState("default")
  const [isPlaying, setIsPlaying] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [transcription, setTranscription] = useState("")

  const handleTextToSpeech = () => {
    if (!text.trim()) return
    setIsPlaying(!isPlaying)
    // In a real implementation, this would call the Speechify API
  }

  const handleRecordToggle = () => {
    setIsRecording(!isRecording)

    // Simulate transcription after stopping recording
    if (isRecording) {
      setTimeout(() => {
        setTranscription(
          "This is a simulated transcription of recorded audio. In a real implementation, this would be the result from a speech-to-text service.",
        )
      }, 1000)
    }
  }

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="text-to-speech">Text to Speech</TabsTrigger>
        <TabsTrigger value="transcription">Transcription</TabsTrigger>
      </TabsList>

      <TabsContent value="text-to-speech">
        <Card>
          <CardHeader>
            <CardTitle>Text to Speech</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="voice-selector">Select Voice</Label>
              <VoiceSelector selectedVoice={selectedVoice} onSelectVoice={setSelectedVoice} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="text-input">Text</Label>
              <Textarea
                id="text-input"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Enter text to convert to speech..."
                className="min-h-[200px]"
              />
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                Upload Text
              </Button>
              <Button onClick={handleTextToSpeech} disabled={!text.trim()}>
                {isPlaying ? (
                  <>
                    <Pause className="h-4 w-4 mr-2" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Play
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="transcription">
        <TranscriptionPanel
          isRecording={isRecording}
          onRecordToggle={handleRecordToggle}
          transcription={transcription}
          onTranscriptionChange={setTranscription}
        />
      </TabsContent>
    </Tabs>
  )
}
