"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Mic, StopCircle, Upload, Download, Copy } from "lucide-react"

interface TranscriptionPanelProps {
  isRecording: boolean
  onRecordToggle: () => void
  transcription: string
  onTranscriptionChange: (text: string) => void
}

export function TranscriptionPanel({
  isRecording,
  onRecordToggle,
  transcription,
  onTranscriptionChange,
}: TranscriptionPanelProps) {
  const handleCopyTranscription = () => {
    navigator.clipboard.writeText(transcription)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Audio Transcription</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-center p-6 border rounded-lg">
          <Button
            size="lg"
            variant={isRecording ? "destructive" : "default"}
            onClick={onRecordToggle}
            className="h-20 w-20 rounded-full"
          >
            {isRecording ? <StopCircle className="h-10 w-10" /> : <Mic className="h-10 w-10" />}
          </Button>
        </div>

        <div className="flex justify-center">
          <p className="text-sm text-muted-foreground">
            {isRecording ? "Recording... Click to stop" : "Click to start recording"}
          </p>
        </div>

        <div className="flex justify-center">
          <Button variant="outline">
            <Upload className="h-4 w-4 mr-2" />
            Upload Audio
          </Button>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-medium">Transcription</h3>
            <div className="flex space-x-2">
              <Button variant="ghost" size="sm" onClick={handleCopyTranscription} disabled={!transcription}>
                <Copy className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" disabled={!transcription}>
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <Textarea
            value={transcription}
            onChange={(e) => onTranscriptionChange(e.target.value)}
            placeholder="Transcription will appear here..."
            className="min-h-[200px]"
          />
        </div>
      </CardContent>
    </Card>
  )
}
