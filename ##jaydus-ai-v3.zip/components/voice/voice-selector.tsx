"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface VoiceSelectorProps {
  selectedVoice: string
  onSelectVoice: (voice: string) => void
}

export function VoiceSelector({ selectedVoice, onSelectVoice }: VoiceSelectorProps) {
  return (
    <Select value={selectedVoice} onValueChange={onSelectVoice}>
      <SelectTrigger className="w-full">
        <SelectValue placeholder="Select Voice" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="default">Default</SelectItem>
        <SelectItem value="male-1">Male Voice 1</SelectItem>
        <SelectItem value="male-2">Male Voice 2</SelectItem>
        <SelectItem value="female-1">Female Voice 1</SelectItem>
        <SelectItem value="female-2">Female Voice 2</SelectItem>
        <SelectItem value="custom">Custom Voice Clone</SelectItem>
      </SelectContent>
    </Select>
  )
}
