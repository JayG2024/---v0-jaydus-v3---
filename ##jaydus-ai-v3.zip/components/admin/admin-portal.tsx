"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UserManagement } from "@/components/admin/user-management"
import { FeatureManagement } from "@/components/admin/feature-management"
import { SubscriptionManagement } from "@/components/admin/subscription-management"
import { AdminDashboard } from "@/components/admin/admin-dashboard"

export function AdminPortal() {
  const [activeTab, setActiveTab] = useState("dashboard")

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
        <TabsTrigger value="users">Users</TabsTrigger>
        <TabsTrigger value="features">Features</TabsTrigger>
        <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
      </TabsList>

      <TabsContent value="dashboard">
        <AdminDashboard />
      </TabsContent>

      <TabsContent value="users">
        <UserManagement />
      </TabsContent>

      <TabsContent value="features">
        <FeatureManagement />
      </TabsContent>

      <TabsContent value="subscriptions">
        <SubscriptionManagement />
      </TabsContent>
    </Tabs>
  )
}
