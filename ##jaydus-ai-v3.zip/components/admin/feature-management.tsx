"use client"

import { useState } from "react"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

type Feature = {
  id: string
  name: string
  description: string
  enabled: boolean
  availableOn: ("free" | "pro" | "enterprise")[]
}

export function FeatureManagement() {
  // Sample features data
  const [features, setFeatures] = useState<Feature[]>([
    {
      id: "1",
      name: "Chat Interface",
      description: "Real-time AI conversations with multiple models",
      enabled: true,
      availableOn: ["free", "pro", "enterprise"],
    },
    {
      id: "2",
      name: "Image Generation",
      description: "Generate images with multiple AI models",
      enabled: true,
      availableOn: ["pro", "enterprise"],
    },
    {
      id: "3",
      name: "Code Canvas",
      description: "Live coding assistance with syntax highlighting",
      enabled: true,
      availableOn: ["pro", "enterprise"],
    },
    {
      id: "4",
      name: "Voice Features",
      description: "Voice cloning and text-to-speech functionalities",
      enabled: true,
      availableOn: ["enterprise"],
    },
    {
      id: "5",
      name: "Advanced Analytics",
      description: "Detailed usage analytics and reporting",
      enabled: false,
      availableOn: ["enterprise"],
    },
  ])

  const toggleFeature = (id: string) => {
    setFeatures(features.map((feature) => (feature.id === id ? { ...feature, enabled: !feature.enabled } : feature)))
  }

  const getPlanBadges = (plans: string[]) => {
    return (
      <div className="flex flex-wrap gap-1">
        {plans.map((plan) => {
          switch (plan) {
            case "free":
              return (
                <Badge key={plan} variant="outline">
                  Free
                </Badge>
              )
            case "pro":
              return (
                <Badge key={plan} variant="default" className="bg-blue-500">
                  Pro
                </Badge>
              )
            case "enterprise":
              return (
                <Badge key={plan} variant="default" className="bg-purple-500">
                  Enterprise
                </Badge>
              )
            default:
              return null
          }
        })}
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Feature Management</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Feature</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Available On</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-[100px]">Toggle</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {features.map((feature) => (
                <TableRow key={feature.id}>
                  <TableCell className="font-medium">{feature.name}</TableCell>
                  <TableCell>{feature.description}</TableCell>
                  <TableCell>{getPlanBadges(feature.availableOn)}</TableCell>
                  <TableCell>
                    <Badge
                      variant={feature.enabled ? "default" : "secondary"}
                      className={feature.enabled ? "bg-green-500" : ""}
                    >
                      {feature.enabled ? "Enabled" : "Disabled"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`feature-${feature.id}`}
                        checked={feature.enabled}
                        onCheckedChange={() => toggleFeature(feature.id)}
                      />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
