"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Search, Plus } from "lucide-react"

type Subscription = {
  id: string
  userId: string
  userName: string
  plan: "free" | "pro" | "enterprise"
  status: "active" | "canceled" | "past_due"
  startDate: Date
  endDate: Date
  amount: number
}

export function SubscriptionManagement() {
  const [searchQuery, setSearchQuery] = useState("")

  // Sample subscriptions data
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([
    {
      id: "1",
      userId: "1",
      userName: "John Doe",
      plan: "enterprise",
      status: "active",
      startDate: new Date("2025-01-15"),
      endDate: new Date("2026-01-15"),
      amount: 499.99,
    },
    {
      id: "2",
      userId: "2",
      userName: "Jane Smith",
      plan: "pro",
      status: "active",
      startDate: new Date("2025-02-20"),
      endDate: new Date("2025-08-20"),
      amount: 49.99,
    },
    {
      id: "3",
      userId: "3",
      userName: "Bob Johnson",
      plan: "free",
      status: "active",
      startDate: new Date("2025-03-10"),
      endDate: new Date("2025-06-10"),
      amount: 0,
    },
    {
      id: "4",
      userId: "4",
      userName: "Alice Williams",
      plan: "pro",
      status: "canceled",
      startDate: new Date("2025-04-05"),
      endDate: new Date("2025-05-05"),
      amount: 49.99,
    },
  ])

  const filteredSubscriptions = subscriptions.filter((subscription) => {
    if (searchQuery) {
      return (
        subscription.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        subscription.plan.toLowerCase().includes(searchQuery.toLowerCase())
      )
    }
    return true
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return (
          <Badge variant="default" className="bg-green-500">
            Active
          </Badge>
        )
      case "canceled":
        return <Badge variant="secondary">Canceled</Badge>
      case "past_due":
        return <Badge variant="destructive">Past Due</Badge>
      default:
        return null
    }
  }

  const getPlanBadge = (plan: string) => {
    switch (plan) {
      case "free":
        return <Badge variant="outline">Free</Badge>
      case "pro":
        return (
          <Badge variant="default" className="bg-blue-500">
            Pro
          </Badge>
        )
      case "enterprise":
        return (
          <Badge variant="default" className="bg-purple-500">
            Enterprise
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Subscription Management</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search subscriptions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8"
            />
          </div>

          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Subscription
          </Button>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Plan</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Start Date</TableHead>
                <TableHead>End Date</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead className="w-[80px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSubscriptions.map((subscription) => (
                <TableRow key={subscription.id}>
                  <TableCell className="font-medium">{subscription.userName}</TableCell>
                  <TableCell>{getPlanBadge(subscription.plan)}</TableCell>
                  <TableCell>{getStatusBadge(subscription.status)}</TableCell>
                  <TableCell>{subscription.startDate.toLocaleDateString()}</TableCell>
                  <TableCell>{subscription.endDate.toLocaleDateString()}</TableCell>
                  <TableCell>${subscription.amount.toFixed(2)}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>Edit</DropdownMenuItem>
                        <DropdownMenuItem>View Details</DropdownMenuItem>
                        <DropdownMenuItem>Upgrade Plan</DropdownMenuItem>
                        <DropdownMenuItem className="text-red-500">Cancel</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
