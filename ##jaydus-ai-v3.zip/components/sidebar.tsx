"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  Code,
  Home,
  ImageIcon,
  MessageSquare,
  Mic,
  Settings,
  Upload,
  Users,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"

interface SidebarItemProps {
  icon: React.ElementType
  label: string
  href: string
  isCollapsed: boolean
}

function SidebarItem({ icon: Icon, label, href, isCollapsed }: SidebarItemProps) {
  const pathname = usePathname()
  const isActive = pathname === href

  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-all",
        isActive ? "bg-accent text-accent-foreground" : "hover:bg-accent/50 hover:text-accent-foreground",
        isCollapsed && "justify-center px-2",
      )}
    >
      <Icon className="h-5 w-5" />
      {!isCollapsed && <span>{label}</span>}
    </Link>
  )
}

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false)

  return (
    <div
      className={cn(
        "flex flex-col border-r bg-background transition-all duration-300",
        isCollapsed ? "w-[60px]" : "w-[240px]",
      )}
    >
      <div className="flex h-16 items-center border-b px-4">
        {!isCollapsed && (
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl font-bold">Jaydus AI</span>
          </Link>
        )}
      </div>
      <div className="flex-1 overflow-auto py-4">
        <nav className="grid gap-1 px-2">
          <SidebarItem icon={Home} label="Dashboard" href="/" isCollapsed={isCollapsed} />
          <SidebarItem icon={MessageSquare} label="Chat" href="/chat" isCollapsed={isCollapsed} />
          <SidebarItem icon={ImageIcon} label="Image Generation" href="/image-generation" isCollapsed={isCollapsed} />
          <SidebarItem icon={Code} label="Code Canvas" href="/code-canvas" isCollapsed={isCollapsed} />
          <SidebarItem icon={Mic} label="Voice Features" href="/voice" isCollapsed={isCollapsed} />
          <SidebarItem icon={Upload} label="File Management" href="/files" isCollapsed={isCollapsed} />
          <SidebarItem icon={Users} label="Admin Portal" href="/admin" isCollapsed={isCollapsed} />
          <SidebarItem icon={Settings} label="Settings" href="/settings" isCollapsed={isCollapsed} />
        </nav>
      </div>
      <div className="border-t p-2">
        <Button variant="ghost" size="icon" onClick={() => setIsCollapsed(!isCollapsed)} className="w-full">
          {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>
    </div>
  )
}
