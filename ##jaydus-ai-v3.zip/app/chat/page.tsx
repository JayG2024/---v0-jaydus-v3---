"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { ChatInterface } from "@/components/chat/chat-interface"
import { ChatHistory } from "@/components/chat/chat-history"
import { Button } from "@/components/ui/button"
import { Menu } from "lucide-react"
import { createNewConversation, getConversationWithMessages } from "@/app/actions/chat-actions"
import type { Message } from "ai"
import { useMediaQuery } from "@/hooks/use-media-query"

export default function ChatPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const conversationId = searchParams.get("id")

  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [initialMessages, setInitialMessages] = useState<Message[]>([])
  const [isLoadingConversation, setIsLoadingConversation] = useState(false)
  const [activeModel, setActiveModel] = useState("gpt-4o")

  const isMobile = useMediaQuery("(max-width: 768px)")

  // Close sidebar on mobile by default
  useEffect(() => {
    if (isMobile) {
      setSidebarOpen(false)
    }
  }, [isMobile])

  // Load conversation if ID is provided
  useEffect(() => {
    if (conversationId) {
      loadConversation(conversationId)
    } else {
      setInitialMessages([])
    }
  }, [conversationId])

  const loadConversation = async (id: string) => {
    setIsLoadingConversation(true)
    try {
      const result = await getConversationWithMessages(id)
      if (result.success) {
        setInitialMessages(result.messages || [])
        if (result.conversation?.model) {
          setActiveModel(result.conversation.model)
        }
      }
    } catch (error) {
      console.error("Error loading conversation:", error)
    } finally {
      setIsLoadingConversation(false)
    }
  }

  const handleNewChat = async () => {
    router.push("/chat")
    setInitialMessages([])
  }

  const handleSelectConversation = (id: string) => {
    router.push(`/chat?id=${id}`)

    // On mobile, close the sidebar after selection
    if (isMobile) {
      setSidebarOpen(false)
    }
  }

  const handleStartNewConversation = async (model: string, firstMessage: string) => {
    try {
      const result = await createNewConversation(model, firstMessage)
      if (result.success && result.conversation) {
        router.push(`/chat?id=${result.conversation.id}`)
        return result.conversation.id
      }
    } catch (error) {
      console.error("Error creating conversation:", error)
    }
    return null
  }

  const handleRegenerateMessage = async (messageId: string) => {
    // This would typically involve:
    // 1. Finding the last user message before this assistant message
    // 2. Sending that message to the API again
    // 3. Replacing the current assistant message with the new one

    // For now, we'll just reload the conversation to demonstrate the concept
    if (conversationId) {
      await loadConversation(conversationId)
    }
  }

  return (
    <div className="flex h-[calc(100vh-64px)]">
      {/* Sidebar */}
      <div
        className={`
          ${sidebarOpen ? "w-64" : "w-0"} 
          md:w-64 
          border-r 
          transition-all 
          duration-300 
          overflow-hidden
          fixed 
          md:relative 
          h-[calc(100vh-64px)] 
          bg-background 
          z-10
        `}
      >
        <ChatHistory
          activeConversationId={conversationId || undefined}
          onNewChat={handleNewChat}
          onSelectConversation={handleSelectConversation}
        />
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-hidden ml-0 md:ml-0">
        <div className="container mx-auto p-4 md:p-6 h-full">
          <div className="flex items-center mb-4">
            <Button variant="ghost" size="icon" className="md:hidden mr-2" onClick={() => setSidebarOpen(!sidebarOpen)}>
              <Menu className="h-5 w-5" />
            </Button>
            <h1 className="text-2xl font-bold">AI Chat</h1>
          </div>

          {isLoadingConversation ? (
            <div className="flex items-center justify-center h-[calc(100vh-180px)]">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <ChatInterface
              initialMessages={initialMessages}
              conversationId={conversationId || undefined}
              onCreateNewConversation={handleStartNewConversation}
              initialModel={activeModel}
              onRegenerateMessage={handleRegenerateMessage}
            />
          )}
        </div>
      </div>
    </div>
  )
}
