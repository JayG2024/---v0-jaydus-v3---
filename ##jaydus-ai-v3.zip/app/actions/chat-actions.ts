"use server"

import { revalidatePath } from "next/cache"
import { cookies } from "next/headers"
import { createServerActionClient } from "@supabase/auth-helpers-nextjs"
import type { Database } from "@/types/database.types"
import type { Message } from "ai"
import * as db from "@/lib/db"

// Get the current user from Supabase Auth
async function getCurrentUser() {
  try {
    const supabase = createServerActionClient<Database>({ cookies })
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session?.user) {
      // For development purposes, return a mock user if not authenticated
      console.log("No authenticated user found, using development fallback user")
      return { id: "00000000-0000-0000-0000-000000000000" }
    }

    return session.user
  } catch (error) {
    console.error("Error getting current user:", error)
    throw new Error(`Authentication error: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

// Create a new conversation
export async function createNewConversation(model: string, initialMessage?: string) {
  try {
    console.log("Creating new conversation with model:", model)
    const user = await getCurrentUser()
    console.log("User ID for new conversation:", user.id)

    const conversation = await db.createConversation(user.id, model)
    console.log("Conversation created:", conversation)

    if (initialMessage) {
      await db.addMessage(conversation.id, "user", initialMessage)
      console.log("Initial message added to conversation")
    }

    revalidatePath("/chat")
    return { success: true, conversation }
  } catch (error) {
    console.error("Error creating conversation:", error)

    // Check if the error is about missing tables
    const errorMessage = error instanceof Error ? error.message : String(error)
    if (errorMessage.includes("does not exist")) {
      return {
        success: false,
        error: "Database tables not set up. Please visit /api/setup-database to create the required tables.",
      }
    }

    return {
      success: false,
      error: `Failed to create conversation: ${errorMessage}`,
    }
  }
}

// Get user's conversations
export async function getUserConversations() {
  try {
    const user = await getCurrentUser()
    const conversations = await db.getUserConversations(user.id)
    return { success: true, conversations }
  } catch (error) {
    console.error("Error getting conversations:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : String(error),
    }
  }
}

// Get a specific conversation with its messages
export async function getConversationWithMessages(conversationId: string) {
  try {
    const conversation = await db.getConversation(conversationId)
    const messages = await db.getConversationMessages(conversationId)

    return {
      success: true,
      conversation,
      messages: db.convertDbMessagesToAiMessages(messages),
    }
  } catch (error) {
    console.error("Error getting conversation:", error)
    return { success: false, error: (error as Error).message }
  }
}

// Save messages to a conversation
export async function saveMessagesToConversation(conversationId: string, messages: Message[]) {
  try {
    // Filter out messages that might already be in the database (have an ID)
    // This is a simple approach - in a production app, you might want to be more sophisticated
    const newMessages = messages.filter(
      (msg) =>
        // Only include user and assistant messages
        msg.role === "user" || msg.role === "assistant",
    )

    // Add each message to the database
    for (const msg of newMessages) {
      await db.addMessage(conversationId, msg.role as any, msg.content)
    }

    revalidatePath("/chat")
    return { success: true }
  } catch (error) {
    console.error("Error saving messages:", error)
    return { success: false, error: (error as Error).message }
  }
}

// Update conversation title
export async function updateConversationTitle(conversationId: string, title: string) {
  try {
    await db.updateConversationTitle(conversationId, title)
    revalidatePath("/chat")
    return { success: true }
  } catch (error) {
    console.error("Error updating conversation title:", error)
    return { success: false, error: (error as Error).message }
  }
}

// Delete a conversation (archive it)
export async function deleteConversation(conversationId: string) {
  try {
    await db.deleteConversation(conversationId)
    revalidatePath("/chat")
    return { success: true }
  } catch (error) {
    console.error("Error deleting conversation:", error)
    return { success: false, error: (error as Error).message }
  }
}

// Pin/unpin a conversation
export async function togglePinConversation(conversationId: string, isPinned: boolean) {
  try {
    await db.pinConversation(conversationId, isPinned)
    revalidatePath("/chat")
    return { success: true }
  } catch (error) {
    console.error("Error toggling pin status:", error)
    return { success: false, error: (error as Error).message }
  }
}
