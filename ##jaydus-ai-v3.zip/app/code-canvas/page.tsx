import { CodeCanvas } from "@/components/code-canvas/code-canvas"

export default function CodeCanvasPage() {
  return (
    <div className="container mx-auto p-6 h-full">
      <h1 className="text-3xl font-bold mb-6">Code Canvas</h1>
      <CodeCanvas />
    </div>
  )
}
