import { NextResponse } from "next/server"
import { createServerSupabaseClient } from "@/lib/supabase"

export const runtime = "nodejs"

export async function POST(req: Request) {
  try {
    const { sql } = await req.json()

    if (!sql) {
      return NextResponse.json(
        {
          success: false,
          error: "No SQL provided",
        },
        { status: 400 },
      )
    }

    const supabase = createServerSupabaseClient()
    const { data, error } = await supabase.rpc("exec_sql", { sql_query: sql })

    if (error) {
      return NextResponse.json(
        {
          success: false,
          error: "Failed to execute SQL",
          details: error,
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "SQL executed successfully",
      data,
    })
  } catch (error) {
    console.error("Error executing SQL:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Error executing SQL",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
