import { NextResponse } from "next/server"
import { createClient } from "openai"

export const runtime = "nodejs"
export const maxDuration = 30 // Set max duration to 30 seconds

export async function POST(req: Request) {
  try {
    const apiKey = process.env.OPENAI_API_KEY
    if (!apiKey) {
      console.error("OpenAI API key is not configured")
      return NextResponse.json({ success: false, error: "OpenAI API key is not configured" }, { status: 500 })
    }

    // Create OpenAI client
    const openai = createClient({ apiKey })

    const formData = await req.formData()
    const audioFile = formData.get("audio") as File | null

    if (!audioFile) {
      console.error("No audio file provided")
      return NextResponse.json({ success: false, error: "No audio file provided" }, { status: 400 })
    }

    // Log file details for debugging
    console.log("Audio file received:", {
      name: audioFile.name || "unnamed",
      type: audioFile.type,
      size: audioFile.size,
    })

    try {
      // Convert File to ArrayBuffer
      const arrayBuffer = await audioFile.arrayBuffer()

      // Create a Node.js Buffer from the ArrayBuffer
      const buffer = Buffer.from(arrayBuffer)

      console.log(`Audio buffer created, size: ${buffer.length} bytes`)

      // Use a simpler approach - directly pass the buffer to OpenAI
      const transcription = await openai.audio.transcriptions.create({
        file: new File([buffer], "audio.webm", { type: "audio/webm" }),
        model: "whisper-1",
        language: "en",
      })

      console.log("Transcription successful:", transcription.text.substring(0, 50) + "...")
      return NextResponse.json({ success: true, text: transcription.text })
    } catch (transcriptionError) {
      console.error("Transcription error:", transcriptionError)
      return NextResponse.json(
        {
          success: false,
          error: "Failed to transcribe audio",
          details: transcriptionError instanceof Error ? transcriptionError.message : String(transcriptionError),
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Error in transcribe API:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Server error processing audio",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
