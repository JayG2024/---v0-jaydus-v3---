import { openai } from "@ai-sdk/openai"
import { generateText } from "ai"
import { NextResponse } from "next/server"

export const runtime = "nodejs"

export async function GET() {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "OpenAI API key is not configured" }, { status: 500 })
    }

    // Simple test to verify OpenAI connection
    const { text } = await generateText({
      model: openai("gpt-3.5-turbo"), // Using a simpler model for the test
      prompt: "Hello, are you working?",
    })

    return NextResponse.json({ success: true, message: "OpenAI API is working correctly", response: text })
  } catch (error) {
    console.error("Error testing OpenAI API:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to connect to OpenAI API",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
