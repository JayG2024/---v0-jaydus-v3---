import { streamText } from "ai"
import { NextResponse } from "next/server"
import { getOpenAIModel, validateOpenAIConfig } from "@/lib/ai-config"
import { saveMessagesToConversation } from "@/app/actions/chat-actions"

export const runtime = "nodejs"

export async function POST(req: Request) {
  try {
    // Validate OpenAI configuration
    try {
      validateOpenAIConfig()
    } catch (error) {
      console.error("OpenAI configuration error:", error)
      return NextResponse.json(
        { error: error instanceof Error ? error.message : "Invalid OpenAI configuration" },
        { status: 500 },
      )
    }

    const { messages, model = "gpt-4o", conversationId } = await req.json()

    // Validate messages
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Invalid or empty messages array" }, { status: 400 })
    }

    // Get the appropriate model
    const aiModel = getOpenAIModel(model)

    // Create the stream
    const result = await streamText({
      model: aiModel,
      messages,
    })

    // If we have a conversationId, save the messages after the response is complete
    if (conversationId) {
      result.text
        .then(async (completedText) => {
          // Create a new array with the assistant's response
          const updatedMessages = [...messages, { role: "assistant", content: completedText }]

          // Save to database
          await saveMessagesToConversation(conversationId, updatedMessages)
        })
        .catch((error) => {
          console.error("Error saving chat history:", error)
        })
    }

    return result.toDataStreamResponse()
  } catch (error) {
    console.error("Error in chat API:", error)
    return NextResponse.json(
      {
        error: "An error occurred during the request",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
