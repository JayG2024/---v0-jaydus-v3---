import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export const runtime = "nodejs"

export async function GET() {
  try {
    // Check if the uuid-ossp extension is available (for UUID generation)
    await supabase.rpc("create_uuid_extension").catch(() => {
      // If the function doesn't exist, try direct SQL
      return supabase.from("_exec").select("*").eq("query", 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp";')
    })

    // Create conversations table
    const { error: conversationsError } = await supabase
      .from("_exec")
      .select("*")
      .eq(
        "query",
        `
      CREATE TABLE IF NOT EXISTS conversations (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID NOT NULL,
        title TEXT,
        model TEXT NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        is_pinned BOOLEAN DEFAULT FALSE,
        is_archived BOOLEAN DEFAULT FALSE,
        metadata JSONB
      );
    `,
      )

    if (conversationsError) {
      return NextResponse.json(
        {
          success: false,
          error: "Failed to create conversations table",
          details: conversationsError,
        },
        { status: 500 },
      )
    }

    // Create messages table
    const { error: messagesError } = await supabase
      .from("_exec")
      .select("*")
      .eq(
        "query",
        `
      CREATE TABLE IF NOT EXISTS messages (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        conversation_id UUID NOT NULL,
        role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
        content TEXT NOT NULL,
        status TEXT DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'failed')),
        tokens_used INTEGER,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        metadata JSONB,
        FOREIGN KEY (conversation_id) REFERENCES conversations(id)
      );
    `,
      )

    if (messagesError) {
      return NextResponse.json(
        {
          success: false,
          error: "Failed to create messages table",
          details: messagesError,
        },
        { status: 500 },
      )
    }

    // Create indexes for better performance
    await supabase
      .from("_exec")
      .select("*")
      .eq(
        "query",
        `
      CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
      CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON messages(conversation_id);
    `,
      )

    return NextResponse.json({
      success: true,
      message: "Database tables created successfully",
    })
  } catch (error) {
    console.error("Error setting up database:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Error setting up database",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
