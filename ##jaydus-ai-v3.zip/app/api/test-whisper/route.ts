import { NextResponse } from "next/server"
import { createClient } from "openai"

export const runtime = "nodejs"

export async function GET() {
  try {
    const apiKey = process.env.OPENAI_API_KEY
    if (!apiKey) {
      return NextResponse.json({ success: false, error: "OpenAI API key is not configured" }, { status: 500 })
    }

    // Create OpenAI client
    const openai = createClient({ apiKey })

    // Test if we can access the models list
    const models = await openai.models.list()

    return NextResponse.json({
      success: true,
      message: "OpenAI client is working correctly",
      models: models.data.slice(0, 5).map((m) => m.id), // Just return first 5 model IDs
    })
  } catch (error) {
    console.error("Error testing OpenAI client:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to connect to OpenAI API",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
