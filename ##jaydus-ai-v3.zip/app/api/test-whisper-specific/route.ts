import { NextResponse } from "next/server"
import { createClient } from "openai"

export const runtime = "nodejs"

export async function GET() {
  try {
    const apiKey = process.env.OPENAI_API_KEY
    if (!apiKey) {
      return NextResponse.json({ success: false, error: "OpenAI API key is not configured" }, { status: 500 })
    }

    // Create OpenAI client
    const openai = createClient({ apiKey })

    // Check if we can access the models list
    try {
      const models = await openai.models.list()

      // Check if whisper-1 is in the list of available models
      const whisperModel = models.data.find((model) => model.id === "whisper-1")

      if (whisperModel) {
        return NextResponse.json({
          success: true,
          message: "OpenAI client and Whisper model are available",
          whisperModel: whisperModel.id,
        })
      } else {
        return NextResponse.json({
          success: false,
          message: "OpenAI client is working but Whisper model is not available",
          availableModels: models.data.slice(0, 10).map((m) => m.id), // Just return first 10 model IDs
        })
      }
    } catch (modelError) {
      console.error("Error accessing OpenAI models:", modelError)
      return NextResponse.json(
        {
          success: false,
          error: "Failed to access OpenAI models",
          details: modelError instanceof Error ? modelError.message : String(modelError),
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Error testing OpenAI Whisper:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to connect to OpenAI API",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
