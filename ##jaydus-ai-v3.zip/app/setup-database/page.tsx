"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2 } from "lucide-react"

export default function SetupDatabasePage() {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [logs, setLogs] = useState<string[]>([])

  const handleSetupDatabase = async () => {
    setLoading(true)
    setSuccess(false)
    setError(null)
    setLogs(["Starting database setup..."])

    try {
      // Create the tables using the SQL script
      const response = await fetch("/api/setup-database")
      const data = await response.json()

      if (data.success) {
        setLogs((prev) => [...prev, "Database tables created successfully"])
        setSuccess(true)
      } else {
        setLogs((prev) => [...prev, `Error: ${data.error || "Unknown error"}`])
        if (data.details) {
          setLogs((prev) => [...prev, `Details: ${JSON.stringify(data.details)}`])
        }
        setError("Failed to set up database")
      }
    } catch (error) {
      console.error("Error setting up database:", error)
      setLogs((prev) => [...prev, `Error: ${error instanceof Error ? error.message : String(error)}`])
      setError("An unexpected error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-6 max-w-2xl">
      <Card>
        <CardHeader>
          <CardTitle>Database Setup</CardTitle>
          <CardDescription>Set up the required database tables for the Jaydus AI platform</CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-4 bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-900">
              <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
              <AlertTitle>Success</AlertTitle>
              <AlertDescription>Database tables have been set up successfully</AlertDescription>
            </Alert>
          )}

          <div className="bg-muted p-4 rounded-md mb-4 h-48 overflow-auto">
            <pre className="text-xs">
              {logs.map((log, index) => (
                <div key={index}>{log}</div>
              ))}
            </pre>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSetupDatabase} disabled={loading} className="w-full">
            {loading ? "Setting up..." : "Set up database tables"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
