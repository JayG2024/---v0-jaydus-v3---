import { DashboardOverview } from "@/components/dashboard/dashboard-overview"

export default function Home() {
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Welcome to Jaydus AI v3</h1>
      <DashboardOverview />
    </div>
  )
}
