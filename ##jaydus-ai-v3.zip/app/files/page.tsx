import { FileManager } from "@/components/files/file-manager"

export default function FilesPage() {
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">File Management</h1>
      <FileManager />
    </div>
  )
}
