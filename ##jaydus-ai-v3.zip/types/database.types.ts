export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          avatar_url: string | null
          created_at: string
          updated_at: string
          last_seen_at: string | null
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
          last_seen_at?: string | null
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
          last_seen_at?: string | null
        }
      }
      plans: {
        Row: {
          id: string
          name: string
          tier: "free" | "pro" | "enterprise"
          price: number
          description: string | null
          features: Json
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          tier: "free" | "pro" | "enterprise"
          price: number
          description?: string | null
          features: Json
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          tier?: "free" | "pro" | "enterprise"
          price?: number
          description?: string | null
          features?: Json
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      subscriptions: {
        Row: {
          id: string
          user_id: string
          plan_id: string
          status: "active" | "canceled" | "past_due" | "trialing" | "incomplete"
          stripe_subscription_id: string | null
          stripe_customer_id: string | null
          current_period_start: string
          current_period_end: string
          cancel_at_period_end: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          plan_id: string
          status?: "active" | "canceled" | "past_due" | "trialing" | "incomplete"
          stripe_subscription_id?: string | null
          stripe_customer_id?: string | null
          current_period_start: string
          current_period_end: string
          cancel_at_period_end?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          plan_id?: string
          status?: "active" | "canceled" | "past_due" | "trialing" | "incomplete"
          stripe_subscription_id?: string | null
          stripe_customer_id?: string | null
          current_period_start?: string
          current_period_end?: string
          cancel_at_period_end?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      usage_limits: {
        Row: {
          id: string
          plan_id: string
          feature: string
          monthly_limit: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          plan_id: string
          feature: string
          monthly_limit: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          plan_id?: string
          feature?: string
          monthly_limit?: number
          created_at?: string
          updated_at?: string
        }
      }
      usage_records: {
        Row: {
          id: string
          user_id: string
          feature: string
          quantity: number
          created_at: string
          metadata: Json | null
        }
        Insert: {
          id?: string
          user_id: string
          feature: string
          quantity: number
          created_at?: string
          metadata?: Json | null
        }
        Update: {
          id?: string
          user_id?: string
          feature?: string
          quantity?: number
          created_at?: string
          metadata?: Json | null
        }
      }
      conversations: {
        Row: {
          id: string
          user_id: string
          title: string | null
          model: string
          created_at: string
          updated_at: string
          is_pinned: boolean
          is_archived: boolean
          metadata: Json | null
        }
        Insert: {
          id?: string
          user_id: string
          title?: string | null
          model: string
          created_at?: string
          updated_at?: string
          is_pinned?: boolean
          is_archived?: boolean
          metadata?: Json | null
        }
        Update: {
          id?: string
          user_id?: string
          title?: string | null
          model?: string
          created_at?: string
          updated_at?: string
          is_pinned?: boolean
          is_archived?: boolean
          metadata?: Json | null
        }
      }
      messages: {
        Row: {
          id: string
          conversation_id: string
          role: "user" | "assistant" | "system"
          content: string
          status: "pending" | "completed" | "failed"
          tokens_used: number | null
          created_at: string
          metadata: Json | null
        }
        Insert: {
          id?: string
          conversation_id: string
          role: "user" | "assistant" | "system"
          content: string
          status?: "pending" | "completed" | "failed"
          tokens_used?: number | null
          created_at?: string
          metadata?: Json | null
        }
        Update: {
          id?: string
          conversation_id?: string
          role?: "user" | "assistant" | "system"
          content?: string
          status?: "pending" | "completed" | "failed"
          tokens_used?: number | null
          created_at?: string
          metadata?: Json | null
        }
      }
      generated_images: {
        Row: {
          id: string
          user_id: string
          prompt: string
          model: string
          image_url: string
          width: number | null
          height: number | null
          created_at: string
          is_favorite: boolean
          metadata: Json | null
        }
        Insert: {
          id?: string
          user_id: string
          prompt: string
          model: string
          image_url: string
          width?: number | null
          height?: number | null
          created_at?: string
          is_favorite?: boolean
          metadata?: Json | null
        }
        Update: {
          id?: string
          user_id?: string
          prompt?: string
          model?: string
          image_url?: string
          width?: number | null
          height?: number | null
          created_at?: string
          is_favorite?: boolean
          metadata?: Json | null
        }
      }
      code_snippets: {
        Row: {
          id: string
          user_id: string
          title: string | null
          language: string
          code: string
          prompt: string | null
          created_at: string
          updated_at: string
          is_pinned: boolean
          metadata: Json | null
        }
        Insert: {
          id?: string
          user_id: string
          title?: string | null
          language: string
          code: string
          prompt?: string | null
          created_at?: string
          updated_at?: string
          is_pinned?: boolean
          metadata?: Json | null
        }
        Update: {
          id?: string
          user_id?: string
          title?: string | null
          language?: string
          code?: string
          prompt?: string | null
          created_at?: string
          updated_at?: string
          is_pinned?: boolean
          metadata?: Json | null
        }
      }
      voice_recordings: {
        Row: {
          id: string
          user_id: string
          title: string | null
          audio_url: string
          duration: number | null
          created_at: string
          metadata: Json | null
        }
        Insert: {
          id?: string
          user_id: string
          title?: string | null
          audio_url: string
          duration?: number | null
          created_at?: string
          metadata?: Json | null
        }
        Update: {
          id?: string
          user_id?: string
          title?: string | null
          audio_url?: string
          duration?: number | null
          created_at?: string
          metadata?: Json | null
        }
      }
      transcriptions: {
        Row: {
          id: string
          recording_id: string | null
          user_id: string
          text: string
          created_at: string
          metadata: Json | null
        }
        Insert: {
          id?: string
          recording_id?: string | null
          user_id: string
          text: string
          created_at?: string
          metadata?: Json | null
        }
        Update: {
          id?: string
          recording_id?: string | null
          user_id?: string
          text?: string
          created_at?: string
          metadata?: Json | null
        }
      }
      voice_clones: {
        Row: {
          id: string
          user_id: string
          name: string
          voice_id: string
          created_at: string
          is_active: boolean
          metadata: Json | null
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          voice_id: string
          created_at?: string
          is_active?: boolean
          metadata?: Json | null
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          voice_id?: string
          created_at?: string
          is_active?: boolean
          metadata?: Json | null
        }
      }
      files: {
        Row: {
          id: string
          user_id: string
          name: string
          type: "document" | "image" | "code" | "data" | "audio" | "other"
          size: number
          file_path: string
          mime_type: string | null
          created_at: string
          updated_at: string
          is_archived: boolean
          metadata: Json | null
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          type: "document" | "image" | "code" | "data" | "audio" | "other"
          size: number
          file_path: string
          mime_type?: string | null
          created_at?: string
          updated_at?: string
          is_archived?: boolean
          metadata?: Json | null
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          type?: "document" | "image" | "code" | "data" | "audio" | "other"
          size?: number
          file_path?: string
          mime_type?: string | null
          created_at?: string
          updated_at?: string
          is_archived?: boolean
          metadata?: Json | null
        }
      }
      folders: {
        Row: {
          id: string
          user_id: string
          name: string
          parent_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          parent_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          parent_id?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      folder_files: {
        Row: {
          folder_id: string
          file_id: string
        }
        Insert: {
          folder_id: string
          file_id: string
        }
        Update: {
          folder_id?: string
          file_id?: string
        }
      }
      notifications: {
        Row: {
          id: string
          user_id: string
          type: "system" | "subscription" | "feature" | "activity"
          title: string
          content: string
          is_read: boolean
          created_at: string
          metadata: Json | null
        }
        Insert: {
          id?: string
          user_id: string
          type: "system" | "subscription" | "feature" | "activity"
          title: string
          content: string
          is_read?: boolean
          created_at?: string
          metadata?: Json | null
        }
        Update: {
          id?: string
          user_id?: string
          type?: "system" | "subscription" | "feature" | "activity"
          title?: string
          content?: string
          is_read?: boolean
          created_at?: string
          metadata?: Json | null
        }
      }
      newsletter_subscribers: {
        Row: {
          id: string
          email: string
          is_subscribed: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          email: string
          is_subscribed?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          is_subscribed?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      newsletter_campaigns: {
        Row: {
          id: string
          title: string
          content: string
          sent_at: string | null
          scheduled_for: string | null
          created_at: string
          updated_at: string
          status: string
          metadata: Json | null
        }
        Insert: {
          id?: string
          title: string
          content: string
          sent_at?: string | null
          scheduled_for?: string | null
          created_at?: string
          updated_at?: string
          status?: string
          metadata?: Json | null
        }
        Update: {
          id?: string
          title?: string
          content?: string
          sent_at?: string | null
          scheduled_for?: string | null
          created_at?: string
          updated_at?: string
          status?: string
          metadata?: Json | null
        }
      }
      knowledge_base_articles: {
        Row: {
          id: string
          title: string
          content: string
          created_at: string
          updated_at: string
          published: boolean
          author_id: string | null
          metadata: Json | null
        }
        Insert: {
          id?: string
          title: string
          content: string
          created_at?: string
          updated_at?: string
          published?: boolean
          author_id?: string | null
          metadata?: Json | null
        }
        Update: {
          id?: string
          title?: string
          content?: string
          created_at?: string
          updated_at?: string
          published?: boolean
          author_id?: string | null
          metadata?: Json | null
        }
      }
      user_integrations: {
        Row: {
          id: string
          user_id: string
          integration_type: string
          credentials: Json | null
          is_active: boolean
          created_at: string
          updated_at: string
          metadata: Json | null
        }
        Insert: {
          id?: string
          user_id: string
          integration_type: string
          credentials?: Json | null
          is_active?: boolean
          created_at?: string
          updated_at?: string
          metadata?: Json | null
        }
        Update: {
          id?: string
          user_id?: string
          integration_type?: string
          credentials?: Json | null
          is_active?: boolean
          created_at?: string
          updated_at?: string
          metadata?: Json | null
        }
      }
      admin_analytics: {
        Row: {
          id: string
          date: string
          active_users: number
          new_users: number
          total_conversations: number
          total_images_generated: number
          total_code_snippets: number
          total_voice_minutes: number
          revenue: number
          metadata: Json | null
        }
        Insert: {
          id?: string
          date: string
          active_users?: number
          new_users?: number
          total_conversations?: number
          total_images_generated?: number
          total_code_snippets?: number
          total_voice_minutes?: number
          revenue?: number
          metadata?: Json | null
        }
        Update: {
          id?: string
          date?: string
          active_users?: number
          new_users?: number
          total_conversations?: number
          total_images_generated?: number
          total_code_snippets?: number
          total_voice_minutes?: number
          revenue?: number
          metadata?: Json | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      plan_tier: "free" | "pro" | "enterprise"
      subscription_status: "active" | "canceled" | "past_due" | "trialing" | "incomplete"
      message_role: "user" | "assistant" | "system"
      message_status: "pending" | "completed" | "failed"
      file_type: "document" | "image" | "code" | "data" | "audio" | "other"
      notification_type: "system" | "subscription" | "feature" | "activity"
    }
  }
}
