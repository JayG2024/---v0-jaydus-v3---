interface Window {
  webkitSpeechRecognition: any
  SpeechRecognition: any
}

declare var SpeechRecognition: any
declare var webkitSpeechRecognition: any
